
import serial
import struct
import time

# === Open UART COM port ===
ser = serial.Serial('COM3', 9600)  # Change COM port as needed
time.sleep(2)  # Wait for FPGA to reset

# === Matrix Dimensions ===
M, N, P = 2, 2, 2

# === Matrix A (row-major) ===
A = [1, 2,
     3, 4]

# === Matrix B (row-major) ===
B = [5, 6,
     7, 8]

# === Helper function ===
def send_word(w):
    ser.write(struct.pack('>I', w))  # Big endian

# === Send matrices ===
send_word(M)
send_word(N)
send_word(P)

for val in A:
    send_word(val)

for val in B:
    send_word(val)

# === Read result ===
print("\nReceiving Result Matrix:")
for i in range(M):
    for j in range(P):
        word_bytes = ser.read(4)
        val = struct.unpack('>I', word_bytes)[0]
        print(f"C[{i}][{j}] = {val} (0x{val:08X})")

ser.close()
